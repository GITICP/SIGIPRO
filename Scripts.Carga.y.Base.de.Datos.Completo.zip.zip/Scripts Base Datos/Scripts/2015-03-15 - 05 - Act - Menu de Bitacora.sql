INSERT INTO seguridad.entradas_menu_principal(id_menu_principal, id_padre, tag, redirect) VALUES (1200, 0,'Auditoría', '/Bitacora/Bitacora');

INSERT INTO seguridad.entradas_menu_principal(id_menu_principal, id_padre, tag, redirect) VALUES (1201, 1200, 'Bitácora', '/Bitacora/Bitacora');