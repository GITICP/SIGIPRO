-- Ejecuta las funciones de fechas
 select seguridad.f_fechasroles(); 
 select seguridad.f_fechasusuario();